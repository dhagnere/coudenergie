<?php
    $sess_username = $_SESSION['username'];
    // $sess_full_name = $_SESSION['full_name'];
    $sess_email = $_SESSION['email'];
    $sess_user_id = $_SESSION['user_id'];

?>
<!-- Start sidebar-wrapper-->
   <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="index.php">
       <img src="../img/logo-icon.png" class="logo-icon" alt="logo icon">
       <h5 class="logo-text">Building Managment</h5>
     </a>
   </div>
   <div class="user-details">
    <div class="media align-items-center user-pointer collapsed" data-toggle="collapse" data-target="#user-dropdown">
      <div class="avatar"><img class="mr-3 side-user-img" src="https://via.placeholder.com/110x110" alt="user avatar"></div>
       <div class="media-body">
       <h6 class="side-user-name"><?php if(isset($sess_username)){
                echo "Hi, ".$sess_username;
              }?></h6>
      </div>
       </div>
     <div id="user-dropdown" class="collapse">
      <ul class="user-setting-menu">
<!--             <li><a href="javaScript:void();"><i class="icon-user"></i>  My Profile</a></li>
            <li><a href="javaScript:void();"><i class="icon-settings"></i> Setting</a></li> -->
      <li><a href="../sign-out.php"><i class="icon-power"></i> Logout</a></li>
      </ul>
     </div>
      </div>
   <ul class="sidebar-menu">
      <li class="sidebar-header">MAIN NAVIGATION</li>
      <li>
        <a href="calendar.html" class="waves-effect">
          <i class="zmdi zmdi-view-dashboard"></i> <span>Home</span>
      	</a>
      </li>
      <li>
        <a href="javaScript:void();" class="waves-effect">
          <i class="zmdi zmdi-home"></i> <span>Buildings</span><i class="fa fa-angle-left pull-right"></i>
        </a>
    		<ul class="sidebar-submenu">
    			<li><a href="add-building.php"><i class="zmdi zmdi-dot-circle-alt"></i> Add Building</a></li>
    			<li><a href="all-buildings.php"><i class="zmdi zmdi-dot-circle-alt"></i> All Buildings</a></li>
    		</ul>
      </li>

      <li>
        <a href="javaScript:void();" class="waves-effect">
          <i class="zmdi zmdi-home"></i> <span>Costs</span><i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="sidebar-submenu">
          <li><a href="add-cost.php"><i class="zmdi zmdi-dot-circle-alt"></i> Add Cost</a></li>
          <li><a href="all-costs.php"><i class="zmdi zmdi-dot-circle-alt"></i> All Costs</a></li>
        </ul>
      </li>

      
    

     
      </ul>
   </div>
   <!--End sidebar-wrapper