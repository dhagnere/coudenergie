<?php
	header('Location: sign-in.php');
?>