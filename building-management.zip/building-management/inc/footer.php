<!--Start footer-->
    <div class="fixed-bottom">	
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          2020 &copy; Building Management | All rights reserved. - Powered By: <a href="https://www.logixxgrid.com" title="Logixx Grid" target="_blank">Logixx Grid </a>
        </div>
      </div>
    </footer>
</div>
	<!--End footer-->